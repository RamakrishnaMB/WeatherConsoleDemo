﻿namespace Weather.Services.Interfaces;

public interface IWeatherService
{
    Task FetchWeatherData();
}